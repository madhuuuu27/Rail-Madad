# Rail-Madad
I developed an AI-powered complaint management system for Rail Madad, leveraging machine learning and AI chatbots to automate complaint intake and resolution. It achieved 75% accuracy in classification and routing, providing real-time updates and insights. The system reduced complaint resolution time by 30%, enhancing customer experience.
